@extends('admin.layouts.admin')

@section('title', 'Admin Panle')

@section('content')

hello world!

@endsection