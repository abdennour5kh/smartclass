<?php $__env->startSection('title', 'Conversation: ' . $conversation->subject); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-white p-4 border">
    <div class="page-title">
        📨 Conversation: <strong><?php echo e($conversation->subject); ?></strong>
    </div>

    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            ✅ <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Error Message -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            ⚠️ Please fix the following issues:
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Messages -->
    <div class="mb-4">
        <?php $__currentLoopData = $conversation->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $isOwn = $message->sender_id === Auth::id();
                $files = $message->studentFiles->merge($message->teacherFiles);
                $roleBadge = ucfirst($message->sender->role);
                $roleColor = match($message->sender->role) {
                    'student' => 'success',
                    'teacher' => 'secondary',
                    'admin' => 'dark',
                    default => 'light'
                };
            ?>

            <div class="mb-3 p-3 rounded <?php echo e($isOwn ? 'bg-primary-subtle text-white' : 'bg-light'); ?>">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                        <strong><?php echo e($message->sender->full_name); ?></strong>
                        <span class="badge text-white bg-<?php echo e($roleColor); ?> ms-2"><?php echo e($roleBadge); ?></span>
                    </div>
                    <small class="<?php echo e($isOwn ? 'text-white-50' : 'text-muted'); ?>">
                        <?php echo e($message->created_at->diffForHumans()); ?>

                    </small>
                </div>

                <p class="mb-1"><?php echo nl2br(e($message->body)); ?></p>

                <?php if($files->count()): ?>
                    <div class="mt-2">
                        <h6 class="d-block mb-1 mt-3">📎 Attachments:</h6>
                        <div class="d-flex flex-wrap gap-2 mt-2">
                            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $fileName = basename($file->file_path);
                                    $fileUrl = asset('storage/' . $file->file_path);
                                    $extension = pathinfo($fileName, PATHINFO_EXTENSION);
                                ?>

                                <a href="<?php echo e($fileUrl); ?>" target="_blank" class="file-pill">
                                    <i class="bi bi-paperclip"></i>
                                    <span><?php echo e($fileName); ?></span>
                                    <span class="badge bg-warning border text-muted text-uppercase"><?php echo e($extension); ?></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Reply Form -->
    <form action="<?php echo e(route(Auth::user()->role . '_reply_conversation', $conversation->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group mb-3">
            <label for="body" class="form-label">✍️ Reply</label>
            <textarea name="body" id="body" class="form-control" rows="4" required></textarea>
        </div>

        <div class="form-group mb-4">
            <label for="files" class="form-label">📁 Attach Files (optional)</label>
            <input type="file" name="files[]" id="files" class="form-control" multiple accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.webp">
            <small class="form-text text-muted">Allowed: PDF, DOC, JPG, PNG, WEBP (Max 10MB each)</small>
        </div>

        <div class="form-group text-end">
            <button type="submit" class="btn btn-primary">Send Reply</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(Auth::user()->role . '.layouts.' . Auth::user()->role, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/conversation.blade.php ENDPATH**/ ?>