<?php $__env->startSection('title', 'My Teachers'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-white p-4 shadow-sm rounded">
    <div class="page-title mb-3">👨‍🏫 My Teachers</div>
    <p class="text-muted mb-4">These are the teachers assigned to your current classes.</p>

    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $currentStudentTeachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card h-100 shadow-sm border-start border-4 border-primary rounded" style="border-left-width: 5px !important;">
                    <div class="card-body d-flex flex-column justify-content-between">
                        <div class="d-flex align-items-center mb-3">
                            <div class="me-3">
                                <img src="<?php echo e($teacher->img_url ? asset('storage/' . $teacher->img_url) : asset('images/default-avatar.png')); ?>"
                                     alt="Avatar" class="rounded-circle" width="50" height="50">
                            </div>
                            <div class="ml-3">
                                <h6 class="mb-0 fw-bold"><?php echo e($teacher->first_name); ?> <?php echo e($teacher->last_name); ?></h6>
                                <small class="text-muted"><?php echo e($teacher->email); ?></small>
                                <div class="text-muted small"><?php echo e($teacher->grade); ?></div>
                            </div>
                        </div>

                        <div class="mb-3 mt-3">
                            <h6 class="text-muted">Teaches:</h6>
                            <ul class="list-unstyled small mb-0 mt-1">
                                <?php $__currentLoopData = $teacher->classes_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>📘 <?php echo e($class['module']); ?> — <span class="text-muted"><?php echo e($class['class_type']); ?></span></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <div class="mt-auto">
                            <a href="<?php echo e(route('student_compose_message', $teacher->user->id)); ?>" class="btn btn-sm btn-outline-primary">📩 Message</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <p class="text-muted">No teachers found for your current classes.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/teachers.blade.php ENDPATH**/ ?>