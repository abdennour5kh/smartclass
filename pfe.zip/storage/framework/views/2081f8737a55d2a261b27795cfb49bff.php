<?php $__env->startSection('title', 'My Classes'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12 stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="card-title"> My classes </div>
        <!-- Search Input -->
        <div class="mb-4">
          <input type="text" id="searchInput" class="form-control" placeholder="Search for module or teacher...">
        </div>
        <?php
        $department = Auth::user()->student->group->section->semester->promotion->department;
        ?>

        <?php if($department->is_group_change_allowed): ?>
        <div class="alert alert-success d-flex justify-content-between align-items-center shadow-sm mb-4" style="background-color: #e9f8ee; border-left: 5px solid #28a745;">
          <div>
            <strong>👥 Group Change Period is Open!</strong>
            <p class="mb-0 small">You can submit a request to move to another group. Make sure to explain your reason clearly.</p>
          </div>
          <div>
            <a href="<?php echo e(route('student_change_group')); ?>" class="btn btn-sm btn-outline-success">✏️ Request Group Change</a>
          </div>
        </div>
        <?php endif; ?>

        <div class="row" id="classesContainer">
          <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 mb-4 class-card">
            <div class="card shadow-sm border-start border-4 border-primary" style="border-left-width: 5px !important;">
              <div class="card-body">
                <h5 class="card-title mb-1">📚 <strong><?php echo e($i['module']->name); ?></strong></h5>
                <p class="text-muted mb-2">👩‍🏫 <?php echo e($i['teacher']); ?> — <em><?php echo e($i['grade']); ?></em></p>

                <div class="mb-2">
                  <span>🧪 <strong>Class Type:</strong> <?php echo e($i['type'] ?? 'N/A'); ?></span>
                </div>

                <div class="d-flex justify-content-between align-items-center mb-1">
                  <span>📈 <strong>Attendance:</strong> <?php echo e($i['attendanceRate']); ?>%</span>
                  <button class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#class<?php echo e($i['id']); ?>">🔎 Details</button>
                </div>

                <div class="progress mb-2" style="height: 6px;">
                  <div class="progress-bar 
                        <?php echo e($i['attendanceRate'] >= 75 ? 'bg-success' : ($i['attendanceRate'] >= 50 ? 'bg-warning' : 'bg-danger')); ?>"
                    role="progressbar"
                    aria-valuenow="<?php echo e($i['attendanceRate']); ?>"
                    aria-valuemin="0"
                    style="width: 50%"
                    id="classesProgressBar"
                    aria-valuemax="100">
                  </div>
                </div>

                <div class="collapse" id="class<?php echo e($i['id']); ?>">
                  <div class="d-flex flex-wrap gap-2 mt-3">
                    <a href="<?php echo e(route('student_class_details', $i['id'])); ?>" class="btn btn-sm btn-secondary ml-2">📄 History</a>
                    <a href="<?php echo e(route('student_announcements', $i['id'])); ?>" class="btn btn-sm btn-info ml-2">📢 Announcements</a>
                    <a href="<?php echo e(route('student_view_tasks', $i['id'])); ?>" class="btn btn-sm btn-danger ml-2">📝 Tasks</a>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
    </div>
  </div>
</div>
<!-- Search Functionality -->
<script>
  document.getElementById('searchInput').addEventListener('input', function() {
    const query = this.value.toLowerCase();
    document.querySelectorAll('.class-card').forEach(card => {
      const content = card.innerText.toLowerCase();
      card.style.display = content.includes(query) ? 'block' : 'none';
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/classes.blade.php ENDPATH**/ ?>