
<!-- Form to add a new semester -->
<form action="<?php echo e(route('admin_store_group')); ?>" method="POST" class="mb-3">
     <?php echo csrf_field(); ?> 
    <div class="row mb-3">
        <div class="col-md-4">
            <div class="input-group">
                <input type="text" name="name" class="form-control" placeholder="Add new section (e.g., Group 10)" required>
            </div>
        </div>
        <div class="col">
            <div class="input-group">
                <select name="promotion_id" id="promotion" class="form-control promotion-select" required>
                <option value="">Select Promotion</option> 
                    <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <option value="<?php echo e($promotion->id); ?>"><?php echo e($promotion->name); ?></option> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col">
        <div class="input-group">                   
            <select name="semester_id" id="semester" class="form-control semester-select" required>
                <option value="">Select Semester</option>
            </select>
        </div>
        </div>
        <div class="col">
        <div class="input-group">                
            <select name="section_id" id="section" class="form-control section-select" required>
                <option value="">Select Section</option>
            </select>
        </div>
        </div>
  </div>
  <button type="submit" class="btn btn-primary">Add</button>
</form>

<?php if(!empty($promotions)): ?>
    <div class="">
        <div class="list-group">

            <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $promo->semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $semester->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php $__currentLoopData = $section->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Item -->
                    <div class="list-group-item structureListGroupItem" data-section="<?php echo e($section->id); ?>">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h6 class="text-muted m-0"><?php echo e($group->name); ?> <?php echo e($section->name); ?> - <?php echo e($semester->name); ?> - <?php echo e($promo->name); ?></h6>
                            </div>
                            <div class="col-md-6 text-md-end">
                                <div class="d-flex flex-wrap justify-content-md-end">
                                    <a href="#" class="btn btn-inverse-warning btn-sm mr-2 select-group-btn" 
                                    data-id="<?php echo e($group->id); ?>" data-name="<?php echo e($group->name); ?>"
                                    data-section="<?php echo e($section->name); ?>" data-semester="<?php echo e($semester->name); ?>" data-semester-id="<?php echo e($semester->id); ?>"
                                    data-promotion="<?php echo e($promo->name); ?>" data-promotion-id="<?php echo e($promo->id); ?>">select</a>
                                    <button class="btn btn-sm btn-inverse-secondary"
                                        data-bs-toggle="collapse"
                                        data-bs-target="#semesterDetails<?php echo e($group->id); ?>"
                                        aria-expanded="false">
                                        details
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="collapse mt-2" id="semesterDetails<?php echo e($group->id); ?>">
                            <div class="d-flex flex-wrap justify-content-between mt-3 mb-2">
                                <p class="mb-1">🗓 Creation Date: <?php echo e($group->created_at); ?></p>
                                <p class="mb-1">🗓 Last Edited: <?php echo e($group->updated_at); ?></p>
                            </div>
                            <p class="text-muted">Students number: <?php echo e(count($group->students)); ?></p>
                            
                            <p class="text-muted">Edit Group Name:</p>
                            <div class="row">
                                <div class="col-md-12">
                                    <form action="<?php echo e(route('admin_update_group', $group->id)); ?>" method="POST" class="mb-3">
                                        <?php echo csrf_field(); ?>
                                        <div class="input-group">
                                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $group->name ?? '')); ?>">
                                            <input type="hidden" name="section_id" value="<?php echo e($section->id); ?>">
                                            <button type="submit" class="btn btn-primary rounded">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php else: ?>
    <!-- leave empty -->
<?php endif; ?>


<?php /**PATH /home/hexzar/Desktop/pfe/resources/views/admin/partials/groups.blade.php ENDPATH**/ ?>