<?php $__env->startSection('title', '📘 Task Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-white" style="padding: 1.5rem 2rem; border: 1px solid #e7eaed;">
    <!-- Task Info -->
    <div class="page-title">📝 Task Information</div>
    <p class="text-muted">Review the task below and submit your work.</p>
    <?php if(session('success')): ?>
    <div class="alert alert-success">✅ <?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <h5 class="mb-3">⚠️ Please fix the following issues:</h5>
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <div class="mb-4">
        <h5 class="mb-2">📌 <strong><?php echo e($task->title); ?></strong></h5>
        <p class="mb-1">🧑‍🏫 Teacher: <strong><?php echo e($task->classe->teacher->user->full_name); ?></strong></p>
        <p class="mb-1">⏳ Deadline: <strong><?php echo e(\Carbon\Carbon::parse($task->deadline)->format('d/m/Y H:i')); ?></strong></p>
        <p class="mt-3">📄 Description:</p>
        <div class="bg-light p-3 rounded border"><?php echo e($task->description); ?></div>
        <?php if($task->teacherFiles->count()): ?>
        <hr>
        <div class="page-title mt-4">📚 Task Resources</div>
        <ul>
            <?php $__currentLoopData = $task->teacherFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $fullName = basename($file->file_path);
            $ext = pathinfo($fullName, PATHINFO_EXTENSION);
            $nameOnly = pathinfo($fullName, PATHINFO_FILENAME);
            $shortName = \Illuminate\Support\Str::limit($nameOnly, 25) . '.' . $ext;
            ?>
            <li>
                <a href="<?php echo e(asset('storage/' . $file->file_path)); ?>" target="_blank">
                    📄 <?php echo e($shortName); ?>

                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>

    </div>

    <hr>

    <?php if(!$submission): ?>
    <!-- Submission Form -->
    <div class="page-title mt-4">📤 Submit Your Task</div>
    <form action="<?php echo e(route('student_submit_task', $task)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group mb-3">
            <label>💬 Message (optional)</label>
            <textarea name="message" class="form-control" rows="4" placeholder="Write a message to your teacher..."><?php echo e(old('message')); ?></textarea>
        </div>

        <div class="form-group mb-3">
            <label>📎 Upload Your Work</label>
            <input type="file" name="files[]" class="form-control" multiple required>
            <small class="form-text text-muted">You can upload multiple files (PDF, DOCX, ZIP, etc.).</small>
        </div>

        <button type="submit" class="btn btn-success">✅ Submit Task</button>
    </form>
    <?php else: ?>
    <!-- Submission Details -->
    <div class="page-title mt-4">📥 Your Submission</div>

    <p>Status:
        <?php if($submission->status == 'pending'): ?>
        ⏳ <span class="badge bg-warning text-dark">Pending</span>
        <?php elseif($submission->status == 'approved'): ?>
        ✅ <span class="badge bg-success">Approved</span>
        <?php else: ?>
        ❌ <span class="badge bg-danger">Refused</span>
        <?php endif; ?>
    </p>

    <p>Grade: <strong><?php echo e($submission->grade ?? '—'); ?></strong></p>
    <p>Feedback: <em><?php echo e($submission->feedback ?? 'No feedback yet'); ?></em></p>

    <?php if($submission->message): ?>
    <p class="mt-3">📝 Your Message:</p>
    <div class="bg-light p-3 border rounded"><?php echo e($submission->message); ?></div>
    <?php endif; ?>

    <?php if($submission->studentFiles->count()): ?>
    <p class="mt-4">📂 Submitted Files:</p>
    <ul>
        <?php $__currentLoopData = $submission->studentFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $fullName = basename($file->file_path);
        $ext = pathinfo($fullName, PATHINFO_EXTENSION);
        $nameOnly = pathinfo($fullName, PATHINFO_FILENAME);
        $shortName = \Illuminate\Support\Str::limit($nameOnly, 25) . '.' . $ext;
        ?>
        <li>
            <a href="<?php echo e(asset('storage/' . $file->file_path)); ?>" target="_blank">
                📄 <?php echo e($shortName); ?>

            </a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/task_submission.blade.php ENDPATH**/ ?>