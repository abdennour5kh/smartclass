<?php $__env->startSection('title', 'Tasks'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-white" style="padding: 1.5rem 1.875rem; border: 1px solid #e7eaed;">
    <div class="page-title">📝 Create New Task</div>
    <p class="text-muted mb-4">Submit a task to a class. Attach documents and set deadlines.</p>

    <?php if(session('success')): ?>
    <div class="alert alert-success">✅ <?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <h5 class="mb-3">⚠️ Please fix the following issues:</h5>
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>


    <form action="<?php echo e(route('teacher_store_task')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label>📘 Class</label>
                    <?php if($classes): ?>
                    <select name="classe_id" class="form-control" required>
                        <option value="">-- Select Class --</option>
                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->group->name); ?> - <?php echo e($classe->module->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php else: ?>
                    do it lates
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>📌 Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
            </div>
        </div>

        <div class="form-group mb-3">
            <label>📝 Description</label>
            <textarea name="description" class="form-control" rows="3" required></textarea>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label>⏰ Deadline</label>
                    <input type="datetime-local" name="deadline" class="form-control" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>📎 Attachment (optional)</label>
                    <input type="file" name="attachments[]" class="form-control" multiple>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-success">➕ Create Task</button>
    </form>

    <!-- Tasks Table Section -->
    <div class="page-title mt-5">📂 Past Tasks</div>
    <p class="text-muted mb-4">Browse tasks you created for your classes.</p>

    <?php if($tasks->isNotEmpty()): ?>
    <div class="table-responsive">
        <table id="taskTable" class="table table-bordered table-hover table-striped">
            <thead class="table-dark">
                <tr>
                    <th>📌 Title</th>
                    <th>📘 Class</th>
                    <th>⏰ Deadline</th>
                    <th>📎 Attachment</th>
                    <th>📅 Created</th>
                    <th>⚙️ Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($task->title); ?></td>
                    <td><?php echo e($task->classe->group->name ?? 'N/A'); ?> - <?php echo e($task->classe->module->name ?? 'N/A'); ?></td>
                    <td><?php echo e($task->deadline); ?></td>
                    <td>
                        <?php if($task->teacherFiles->isNotEmpty()): ?>
                        <?php $__currentLoopData = $task->teacherFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="btn btn-sm btn-danger" href="<?php echo e(asset('storage/' . $file->file_path)); ?>" target="_blank">📄 Download</a><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        No file
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($task->created_at->format('d M Y')); ?></td>
                    <td>
                        <!-- Your action buttons here -->
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <p class="text-muted">No tasks found.</p>
    <?php endif; ?>


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        let table = $('#taskTable').DataTable({
            "ordering": true,
            "pageLength": 10,
            "language": {
                "search": "",
                "searchPlaceholder": "🔍 Search tasks..."
            }
        });

        $('#taskSearch').on('keyup', function() {
            table.search(this.value).draw();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('teacher.layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/teacher/create_task.blade.php ENDPATH**/ ?>