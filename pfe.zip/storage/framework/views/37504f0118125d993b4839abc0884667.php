<?php $__env->startSection('title', 'Classes Overview'); ?>
<?php $__env->startSection('content'); ?>
<style>
.card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.12);
}
.card-header {
    background: linear-gradient(to right, #007bff, #0056b3);
}
</style>
<div class="container-fluid bg-white" style="padding: 1.5rem 1.875rem !important;border: 1px solid #e7eaed !important;">
    <div class="page-title">
    📚 Classes Overview
    </div>
    <p class="text-muted mb-5">Find & Manage your classes with ease.</p>

    <?php if($classes->isEmpty()): ?>
    <p>Sorry, there are no classes for the selected group. Please create a class first: 
        <strong><a href="<?php echo e(route('admin_academic_structure')); ?>">Create Class</a></strong>
    </p>
    <?php else: ?>
        <div class="row">
            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card classe-card shadow-sm rounded-4 h-100" style="cursor: pointer;" data-id="<?php echo e($class->id); ?>">
                        <div class="card-header bg-primary text-white rounded-top-4 d-flex justify-content-between align-items-center">
                            <h5 class="mb-0 fw-semibold">
                                🧠 <?php echo e($class->module->name); ?> – Group <?php echo e($class->group->name); ?>

                            </h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled mb-0">
                                <li><strong>📚 Module:</strong> <?php echo e($class->module->name); ?></li>
                                <li><strong>👥 Group:</strong> <?php echo e($class->group->name); ?></li>
                                <li><strong>🏛️ Section:</strong> <?php echo e($class->group->section->name); ?></li>
                                <li><strong>🎓 Promotion:</strong> <?php echo e($class->group->section->semester->promotion->name); ?></li>
                                <li><strong>🧪 Type:</strong> <?php echo e($class->class_type); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

</div>
<script>
    $('.classe-card').on('click', function() {
        classe_id = $(this).data('id');
        window.location.href = '/teacher/manage_classe/' + classe_id;
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('teacher.layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/teacher/classes_overview.blade.php ENDPATH**/ ?>