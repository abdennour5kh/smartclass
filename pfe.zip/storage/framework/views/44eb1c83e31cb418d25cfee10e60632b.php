<style>

</style>

<!-- Justification List -->
<div class="list-group">
    <?php $__empty_1 = true; $__currentLoopData = $newJustifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $justification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="list-group-item">
            <div class="d-flex justify-content-between align-items-start flex-column flex-md-row">
                <div>
                    <div class="mt-2 mt-md-0">
                        <h6 class="text-muted mb-0">
                            <strong><?php echo e($justification->student->first_name); ?> <?php echo e($justification->student->last_name); ?></strong>
                            submitted a justification for
                            <strong><?php echo e($justification->session->classe->module->name); ?></strong>
                            (<?php echo e($justification->session->session_date); ?>)
                        </h6>
                    </div>
                </div>
                <div class="mt-2 mt-md-0 text-md-end">
                <form action="<?php echo e(route('teacher_update_justification')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="justification_id" value="<?php echo e($justification->id); ?>">
                    <input type="hidden" name="action" value="approve">
                    <button type="submit" class="btn btn-sm btn-success me-2">✅ Approve</button>
                </form>

                <form action="<?php echo e(route('teacher_update_justification')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="justification_id" value="<?php echo e($justification->id); ?>">
                    <input type="hidden" name="action" value="refuse">
                    <button type="submit" class="btn btn-sm btn-danger me-2">❌ Refuse</button>
                </form>

                    <button class="btn btn-sm btn-inverse-secondary"
                            data-bs-toggle="collapse"
                            data-bs-target="#justificationDetails<?php echo e($justification->id); ?>"
                            aria-expanded="false"
                            aria-controls="justificationDetails<?php echo e($justification->id); ?>">
                        ⬇️ Details
                    </button>
                </div>
            </div>

            <!-- Expanded details -->
            <div class="collapse mt-3" id="justificationDetails<?php echo e($justification->id); ?>">
                <div class="bg-light border rounded p-3">
                    <div class="row mb-2">
                        <div class="col-md-6">
                            <p class="mb-1"><strong>👤 Student:</strong> <?php echo e($justification->student->first_name); ?> <?php echo e($justification->student->last_name); ?></p>
                            <p class="mb-1"><strong>👥 Group:</strong> <?php echo e($justification->session->classe->group->name); ?></p>
                            <p class="mb-1"><strong>📚 Module:</strong> <?php echo e($justification->session->classe->module->name); ?>, <?php echo e($justification->session->classe->class_type); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-1"><strong>🗓 Session Date:</strong> <?php echo e($justification->session->session_date); ?></p>
                            <p class="mb-1"><strong>📤 Submitted:</strong> <?php echo e($justification->created_at->format('Y-m-d H:i')); ?></p>
                            <p class="mb-1"><strong>🏛 Admin Decision:</strong>
                                <?php
                                    $adminStatus = $justification->admin_decision;
                                    $adminLabel = 'Not Reviewed';
                                    $adminClass = 'secondary';

                                    if ($adminStatus === '1') {
                                        $adminLabel = 'Approved';
                                        $adminClass = 'success';
                                    } elseif ($adminStatus === '0') {
                                        $adminLabel = 'Rejected';
                                        $adminClass = 'danger';
                                    } elseif ($adminStatus === '2') {
                                        $adminLabel = 'Under Review';
                                        $adminClass = 'warning text-dark';
                                    }
                                ?>
                                <span class="badge bg-<?php echo e($adminClass); ?>"><?php echo e($adminLabel); ?></span>
                            </p>
                        </div>
                    </div>

                    <div class="mb-3">
                        <strong>📝 Full message:</strong>
                        <div class="border rounded p-2 bg-white mt-1 text-muted">
                            <?php echo e($justification->message ?: 'No message.'); ?>

                        </div>
                    </div>

                    <div>
                        <strong>📎 Attached Files:</strong>
                        <div class="d-flex flex-wrap gap-2 mt-2">
                            <?php $__empty_2 = true; $__currentLoopData = $justification->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <?php
                                    $fileName = basename($file->file_path);
                                    $fileUrl = asset('storage/' . $file->file_path);
                                    $extension = pathinfo($fileName, PATHINFO_EXTENSION);
                                ?>
                                <a href="<?php echo e($fileUrl); ?>" target="_blank" class="file-pill">
                                    <i class="bi bi-paperclip"></i>
                                    <span><?php echo e($fileName); ?></span>
                                    <span class="badge bg-warning border text-muted text-uppercase"><?php echo e($extension); ?></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <em class="text-muted">No files uploaded.</em>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="list-group-item text-center py-5 text-muted">
            <i class="bi bi-inbox fs-4 d-block mb-2"></i>
            No justification requests at the moment.
        </div>
    <?php endif; ?>
</div>

<!-- View History Button -->
<div class="mt-4 text-end">
    <a href="" class="btn btn-outline-secondary">
        📜 View Full Justification History
    </a>
</div>
<?php /**PATH /home/hexzar/Desktop/pfe/resources/views/teacher/partials/justifications.blade.php ENDPATH**/ ?>