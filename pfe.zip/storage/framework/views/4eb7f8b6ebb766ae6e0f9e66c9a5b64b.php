
<p class="text-muted">You can add new Promotion, or select Promotion to add Semester.</p>
<!-- Form to add a new promotion -->
<form action="<?php echo e(route('admin_store_promotion')); ?>" method="POST" class="mb-3">
    <?php echo csrf_field(); ?>
    <div class="input-group">
        <input type="text" name="name" class="form-control" placeholder="Add new promotion (e.g., Licence 1ère année)" required>
        <button type="submit" class="btn btn-primary">Add</button>
    </div>
</form>

<?php if(!empty($promotions)): ?>
<div class="">
    <div class="list-group">

        <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Promotion 1 -->
        <div class="list-group-item structureListGroupItem" data-promotion="<?php echo e($promo->id); ?>">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h6 class="text-muted m-0"><?php echo e($promo->name); ?></h6>
                </div>
                <div class="col-md-6 text-md-end">
                    <div class="d-flex flex-wrap justify-content-md-end">
                        <a href="" class="btn btn-inverse-warning btn-sm mr-2 select-promotion-btn"
                        data-id="<?php echo e($promo->id); ?>" data-name="<?php echo e($promo->name); ?>" >select</a>
                        <button class="btn btn-sm btn-inverse-secondary" data-bs-toggle="collapse" data-bs-target="#semester1Details<?php echo e($promo->id); ?>" aria-expanded="false">
                        details
                        </button>
                        
                    </div>
                </div>
            </div>
            <div class="collapse mt-2" id="semester1Details<?php echo e($promo->id); ?>">
                <div class="d-flex flex-wrap justify-content-between mt-3 mb-2">
                <p class="mb-1">🗓 Creation Date: <?php echo e($promo->created_at); ?></p>
                <p class="mb-1">🗓 Last Edited: <?php echo e($promo->updated_at); ?></p>
                </div>
                <p class="text-muted">Semesters:</p>
                <div class="d-flex">
                                <?php if(count($promo->semesters) > 0): ?>
                                    <ul>
                                        <?php $__currentLoopData = $promo->semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($semester->name); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php else: ?>
                                    <p>no semesters yet !</p>
                                <?php endif; ?>
                            </div>
                <p class="text-muted">Edit Promotion Name:</p>
                <div class="row">
                    <div class="col-md-12">
                        <form action="<?php echo e(route('admin_update_promotion', $promo->id)); ?>" method="POST" class="mb-3">
                            <?php echo csrf_field(); ?>
                            <div class="input-group">
                                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $promo->name ?? '')); ?>">
                                <button type="submit" class="btn btn-primary rounded">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    </div>
</div>
<?php else: ?>
    <!-- leave empty -->
<?php endif; ?>

<?php /**PATH /home/hexzar/Desktop/pfe/resources/views/admin/partials/promotions.blade.php ENDPATH**/ ?>