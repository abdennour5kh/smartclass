<?php $__env->startSection('title', 'Admin Panle'); ?>

<?php $__env->startSection('content'); ?>

hello world!

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>