<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title mb-5">🛠️ Update Your Profile</h4>
                <div class="card-discreption">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        ✅ <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <h5 class="mb-3">⚠️ Please fix the following issues:</h5>
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                </div>
                <form method="POST" action="<?php echo e(route('teacher_update_profile')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="first_name">🧍 First Name</label>
                                <input type="text" class="form-control" name="first_name" value="<?php echo e(old('first_name', $teacher->first_name)); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="last_name">🧍 Last Name</label>
                                <input type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name', $teacher->last_name)); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="email">📧 Email</label>
                                <input type="email" class="form-control" name="email" value="<?php echo e(old('email', $teacher->email)); ?>" required>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="phone_number">📱 Phone Number</label>
                                <input type="text" class="form-control" name="phone_number" value="0<?php echo e(old('phone_number', $teacher->phone_number)); ?>">
                            </div>
                        </div>

                        <div class="col">
                            <div class="form-group mb-3">
                                <label for="grade">🎓 Grade</label>
                                <input type="text" class="form-control" name="grade" value="<?php echo e(old('grade', $teacher->grade)); ?>" readonly>
                            </div>

                            <div class="form-group mb-4">
                                <label for="address">📍 Address</label>
                                <textarea class="form-control" name="address" rows="3"><?php echo e(old('address', $teacher->address)); ?></textarea>
                            </div>

                            <?php if($teacher->img_url): ?>
                                <img src="<?php echo e(asset('storage/' . $teacher->img_url)); ?>" class="rounded-circle mb-2" width="100" height="100" alt="Teacher Avatar">
                            <?php else: ?>
                                <img src="<?php echo e(asset('images/default-avatar.png')); ?>" class="rounded-circle mb-2" width="100" height="100" alt="Default Avatar">
                            <?php endif; ?>
                            <div class="form-group mb-5">
                                <label for="avatar" class="form-label">🖼️ Profile Avatar</label>
                                <input class="form-control" type="file" id="avatar" name="avatar" accept="image/*">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mb-5">💾 Save Changes</button>
                </form>
                <hr>
                <h4 class="card-title mb-5 mt-5">🔐 Change Password</h4>
                <form method="POST" action="<?php echo e(route('teacher_update_password')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-3">
                        <label for="current_password">🔑 Current Password</label>
                        <input type="password" class="form-control" name="current_password" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="new_password">🆕 New Password</label>
                        <input type="password" class="form-control" name="new_password" required>
                    </div>
                    <div class="form-group mb-4">
                        <label for="new_password_confirmation">✅ Confirm New Password</label>
                        <input type="password" class="form-control" name="new_password_confirmation" required>
                    </div>
                    <button type="submit" class="btn btn-warning">🔁 Update Password</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/teacher/profile.blade.php ENDPATH**/ ?>