    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row" style="position: fixed;">
            <div class="navbar-brand-wrapper d-flex justify-content-center">
        <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">  
          <a class="navbar-brand brand-logo" href="index.html"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo"/></a>
          <a class="navbar-brand brand-logo-mini" href="index.html"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo"/></a>
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-sort-variant"></span>
          </button>
        </div>  
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item dropdown mr-1">
            <a class="nav-link count-indicator dropdown-toggle d-flex justify-content-center align-items-center" id="messageDropdown" href="#" data-toggle="dropdown">
              <i class="mdi mdi-message-text mx-0"></i>
              <?php if($conversations->count()): ?>
                <span class="count"></span>
              <?php endif; ?>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="messageDropdown">
              <p class="mb-0 font-weight-normal float-left dropdown-header">Messages</p>
              <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a class="dropdown-item" href="<?php echo e(route('student_show_conversation', $cv)); ?>">
                  <div class="item-thumbnail">
                      <img src="<?php echo e($cv->messages->last()->sender->avatar_url); ?>" alt="image" class="profile-pic">
                  </div>
                  <div class="item-content flex-grow">
                    <h6 class="ellipsis font-weight-normal"><?php echo e($cv->messages->last()->sender->full_name); ?>

                    </h6>
                    <p class="font-weight-light small-text text-muted mb-0">
                      <?php echo e($cv->subject); ?>

                    </p>
                  </div>
                </a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <span class="dropdown-item text-muted">📬 No new messages</span>
              <?php endif; ?>
            </div>
          </li>
          <li class="nav-item dropdown mr-4">
              <a class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center notification-dropdown"
                id="notificationDropdown" href="#" data-toggle="dropdown">
                  <i class="mdi mdi-bell mx-0"></i>
                  <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
                    <span class="count">
                        <?php echo e(auth()->user()->unreadNotifications->count()); ?>

                    </span>
                  <?php endif; ?>
              </a>

              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="notificationDropdown">
                  <p class="mb-0 font-weight-normal float-left dropdown-header">Notifications</p>

                  <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <?php
                          $type = class_basename($notification->type);
                          $icon = 'mdi-bell-outline';
                          $bg = 'bg-info';

                          if ($type === 'JustificationReviewed') {
                              $icon = 'mdi-information';
                              $bg = 'bg-success';
                          } elseif ($type === 'SomeImportantNotification') {
                              $icon = 'mdi-alert-circle-outline';
                              $bg = 'bg-warning';
                          }
                      ?>

                      <a class="dropdown-item" href="#">
                          <div class="item-thumbnail">
                              <div class="item-icon <?php echo e($bg); ?>">
                                  <i class="mdi <?php echo e($icon); ?> mx-0"></i>
                              </div>
                          </div>
                          <div class="item-content">
                              <h6 class="font-weight-normal">
                                  <?php echo e($notification->data['message'] ?? 'New notification'); ?>

                              </h6>
                              <p class="font-weight-light small-text mb-0 text-muted">
                                  <?php echo e($notification->created_at->diffForHumans()); ?>

                              </p>
                          </div>
                      </a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <div class="dropdown-item text-center text-muted">
                          No new notifications
                      </div>
                  <?php endif; ?>

                  <div class="dropdown-divider"></div>

                  <form method="POST" action="<?php echo e(route('notifications.markAllRead')); ?>">
                      <?php echo csrf_field(); ?>
                      <button type="submit" class="dropdown-item text-center text-primary small border-0 bg-transparent">
                          📬 Mark all as read
                      </button>
                  </form>
              </div>
          </li>

          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              <img src="<?php echo e($student->user->avatar_url); ?>" alt="profile"/>
              <span class="nav-profile-name"><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <a class="dropdown-item" href="<?php echo e(route('student_profile')); ?>">
                <i class="mdi mdi-settings text-primary"></i>
                Profile
              </a>
              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                <i class="mdi mdi-logout text-primary"></i>
                Logout
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/partials/navbar.blade.php ENDPATH**/ ?>