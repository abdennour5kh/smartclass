<?php $__env->startSection('title', 'Document Requests'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-white p-4 shadow-sm rounded">
    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        ✅ <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <!-- Error Message -->
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        ⚠️ Please fix the following issues:
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
<div class="alert alert-primary shadow-sm border border-primary-subtle px-4 py-3 rounded mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div class="flex-grow-1">
            <h6 class="mb-1 fw-bold text-primary">📄 Request a Document</h6>
            <p class="mb-0 text-muted small">Select the type of document you need and submit your request instantly.</p>
        </div>

        <form action="<?php echo e(route('student_store_document_request')); ?>" method="POST" class="d-flex flex-wrap align-items-center gap-2" style="min-width: 360px;">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-0 mt-1" style="min-width: 200px;margin-right: 5px;">
                <select name="document_type" class="form-control" style="background: white;padding: 0.5rem 0.81rem !important;/*! border: 1px solid #4ebe38; *//*! margin-left: 5px; */color: #4d46468f !important;outline: 1px solid #4ebe38 !important;height: auto;" required>
                    <?php $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group mb-0 mt-1">
                <button type="submit" class="btn btn-sm btn-primary">📨 Request</button>
            </div>
        </form>
    </div>
</div>


    
    <hr class="my-4">
    <div class="page-title mb-3">📋 Previous Requests</div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped text-center" id="smartClassTable">
            <thead class="table-light">
                <tr>
                    <th>📄 Document Type</th>
                    <th>📅 Requested At</th>
                    <th>⏳ Status</th>
                    <th>🗨️ Admin Response</th>
                    <th>📥 Download</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $documentRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($request->document_type); ?></td>
                        <td><?php echo e($request->created_at->format('d/m/Y H:i')); ?></td>
                        <td>
                            <?php if($request->status === 'pending'): ?>
                                <span class="badge bg-warning text-dark">Pending</span>
                            <?php elseif($request->status === 'approved'): ?>
                                <span class="badge bg-success">Approved</span>
                            <?php elseif($request->status === 'rejected'): ?>
                                <span class="badge bg-danger">Rejected</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($request->admin_response ?? '—'); ?></td>
                        <td>
                            <?php if($request->status === 'approved' && $request->document_path): ?>
                                <a href="<?php echo e(asset('storage/' . $request->document_path)); ?>" class="btn btn-sm btn-success" target="_blank">
                                    📥 Download
                                </a>
                            <?php else: ?>
                                <button class="btn btn-sm btn-secondary" disabled>Not Available</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">No document requests yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/documents.blade.php ENDPATH**/ ?>