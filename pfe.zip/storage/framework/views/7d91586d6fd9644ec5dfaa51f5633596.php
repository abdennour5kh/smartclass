<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<?php if($announcements->count() > 0): ?>
<div id="ac-bord" style="margin-bottom: 15px;">
    <!-- Swiper Container -->
    <div class="swiper announcement">
        <h4 class="text-white m-0 p-1" style="font-weight: bold;font-size: 30px;padding-left: 10px !important;padding-top: 13px !important;">Classe Announcements :</h4>
        <div class="swiper-wrapper">
            <!-- Slide 1 -->
            <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide">
                <div class="card bg-transparent">
                    <div class="card-body text-white p-1">
                        <h6 class="card-title text-white m-0" style="font-weight: initial;padding: 10px !important;padding-top: 20px !important;">
                            Prof <strong><?php echo e($ac->Classe->teacher->first_name); ?> <?php echo e($ac->Classe->teacher->last_name); ?></strong> | at <strong><?php echo e($ac->created_at->format('h:i A d/m/Y')); ?></strong>
                        </h6>
                        <p class="card-description text-white m-0" style="padding-left: 10px !important;padding-top: 10px !important;">
                            <?php echo nl2br(e($ac->content)); ?>

                        </p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="swiper-pagination"></div>

    </div>
    <style>
        .announcement {
            padding: 10px;
            background: url('<?php echo e(asset("images/ac_background.jpg")); ?>') no-repeat center center,
            #7cd175;
            /* This is the fallback color */
            background-size: cover;
            /* Make the image cover the area */
            border-radius: 4px;
        }

        .announcement::before {
            content: "";
            position: absolute;
            inset: 0;
            background: rgba(39, 184, 26, 0.7);
            /* semi-transparent green overlay */
            z-index: 0;
            border-radius: 4px;
        }

        .swiper>* {
            position: relative;
            z-index: 1;
        }

        .swiper {
            position: relative;
            overflow: hidden;
        }

        .swiper-pagination-bullet {
            background: #ffff;
            /* your primary color */
            opacity: 0.4;
        }

        .swiper-pagination-bullet-active {
            opacity: 1;
        }

        .swiper-slide {
            width: auto;
        }
    </style>
</div>
<?php endif; ?>
<div class="row">
    <div class="col-md-12 stretch-card">
        <div class="card" style="margin-bottom: 15px;">
            <div class="card-body">
                <h2 class="card-title d-flex justify-content-between align-items-center">
                    Classes
                    <span class="d-flex gap-0 fs-4">
                        <div id="swiper-prev" class="cursor-pointer"><i class="mdi mdi-chevron-left" style="font-size: 20px;"></i></div>
                        <div id="swiper-next" class="cursor-pointer"><i class="mdi mdi-chevron-right" style="font-size: 20px;"></i></div>
                    </span>
                </h2>
                <?php if(count($classesReport) > 0): ?>
                <div class="swiper" id="classes">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $classesReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Slide 1 -->
                        <div class="swiper-slide">
                            <a href="<?php echo e(route('student_class_details', $class['id'])); ?>" class="text-decoration-none">
                                <div class="card border-0 rounded-4 overflow-hidden shadow-sm">
                                    <img src="<?php echo e($class['module']->img_url ? asset('storage/' . $class['module']->img_url) : asset('images/default-image.jpg')); ?>"
                                        class="card-img-top card-img-class"
                                        alt="Classe Image"
                                        style="height: 150px; object-fit: cover;">
                                    <div class="card-body p-0 pt-3">
                                        <div class="class-card">
                                            <span class="badge class-badge mb-3 mt-1"><?php echo e($class['teacher']); ?></span>
                                            <span class="badge class-badge mb-3 mt-1"><?php echo e($class['type']); ?></span>
                                        </div>

                                        <h5 class="card-title mb-3"><?php echo e($class['module']->name); ?></h5>


                                        <!-- Progress Bar -->
                                        <div class="progress" style="height: 6px; border-radius: 10px;">
                                            <div class="progress-bar " id="classesProgressBar" role="progressbar" style="width: 40%;" aria-valuenow="<?php echo e($class['attendanceRate']); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
                <?php else: ?>
                <p>Classes has not started yet.</p>
                <?php endif; ?>


            </div>
        </div>

    </div>
</div>
<div class="row">
    <div class="col-md-12 stretch-card">
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">
                    Tasks
                </h2>
                <p class="card-description">
                    Keep up the hard work
                </p>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped" id="smartClassTable">
                        <thead>
                            <tr>
                                <th>📘 Module</th>
                                <th>📝 Task Title</th>
                                <th>📅 Deadline</th>
                                <th>✅ Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($task->classe->module->name); ?></td>
                                <td><a class="text-primary" href="<?php echo e(route('student_submit_task', $task->id)); ?>"><?php echo e($task->title); ?></a></td>
                                <td><?php echo e($task->deadline); ?></i></td>
                                <?php
                                $submission = $task->submissions->first(); // because we already filtered for current student
                                ?>

                                <?php if($submission): ?>
                                <?php if($submission->status === 'pending'): ?>
                                <td><label class="badge badge-warning">Pending</label></td>
                                <?php elseif($submission->status === 'approved'): ?>
                                <td><label class="badge badge-success">Approved</label></td>
                                <?php elseif($submission->status === 'refused'): ?>
                                <td><label class="badge badge-danger">Refused</label></td>
                                <?php endif; ?>
                                <?php else: ?>
                                <td><label class="badge badge-secondary">Not Submitted</label></td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td colspan="4">No Tasks for the moment, stay ready.</td>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const colors = [
            '#4ebe38', '#007bff', '#ffc107', '#e83e8c', '#20c997', '#6610f2',
            '#fd7e14', '#6f42c1', '#17a2b8', '#dc3545', '#28a745', '#ff6f61',
            '#00b894', '#0984e3', '#e17055', '#b71540', '#8e44ad', '#2ecc71',
            '#f39c12', '#1abc9c', '#c0392b', '#6c5ce7', '#d63031'
        ];
        // Loop through each class card
        document.querySelectorAll('.class-card').forEach(card => {
            const color = colors[Math.floor(Math.random() * colors.length)];
            const transparent = color + '42';

            // Apply color to all badges inside this class card
            card.querySelectorAll('.class-badge').forEach(badge => {
                badge.style.backgroundColor = transparent;
                badge.style.color = color;
            });
        });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/dashboard.blade.php ENDPATH**/ ?>