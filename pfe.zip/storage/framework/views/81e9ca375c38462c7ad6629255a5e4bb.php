<?php $__env->startSection('title', 'Announcements'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="card-title">
                    Announcements
                </div>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        ✅ <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <h5 class="mb-3">⚠️ Please fix the following issues:</h5>
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form class="forms-sample" method="POST" action="<?php echo e(route('teacher_announcement_add')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if($classes): ?>
                        <div class="form-group">
                            <label for="exampleFormControlSelect3">Select Group & Module</label>
                            <select name="classes_id" class="form-control form-control-sm" id="exampleFormControlSelect3" required>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->group->name); ?> - <?php echo e($classe->module->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            </select>
                        </div>
                    <?php elseif($classe): ?>
                    <div class="form-group">
                            <label for="exampleFormControlSelect3">Select Group & Module</label>
                            <select name="classes_id" class="form-control form-control-sm" id="exampleFormControlSelect3" required>
                               
                                    <option value="<?php echo e($classe->id); ?>" selected><?php echo e($classe->group->name); ?> - <?php echo e($classe->module->name); ?></option>
                            </select>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                      <label for="exampleTextarea1">Announcement Content</label>
                      <textarea name="content" class="form-control" id="exampleTextarea1" rows="4"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                </form>
                <hr class="my-5">
                <div class="card-title">
                    Your Announcements
                </div>  
                <?php if($announcements->count() > 0): ?>
                    <div class="list-group">
                        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?php echo e($announcement->group->name); ?> - <?php echo e($announcement->module->name); ?></strong><br>
                                        <small class="text-muted"><?php echo e($announcement->created_at->format('d M Y, H:i')); ?></small>
                                        <p class="mb-0 mt-2"><?php echo e($announcement->content); ?></p>
                                    </div>
                                    <div class="text-end">
                                    <form action="<?php echo e(route('teacher_delete_announcement', $announcement->id)); ?>" 
                                        method="POST" style="display:inline;" 
                                        onsubmit="return confirm('Are you sure you want to delete this announcement?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No announcements posted yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/teacher/announcements.blade.php ENDPATH**/ ?>