<style>
    .list-group-item:hover {
        background-color: #f8f9fa !important;
    }
</style>

<?php if($conversations->count()): ?>
    <div class="list-group rounded border shadow-sm">
        <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $isUnread = $conversation->pivot->last_read_at === null ||
                            $conversation->updated_at->gt($conversation->pivot->last_read_at);

                $lastMessage = $conversation->messages->last();
                $files = $lastMessage->studentFiles->merge($lastMessage->teacherFiles);
                $hasAttachments = $files->isNotEmpty();
                $preview = Str::limit(strip_tags($lastMessage->body), 100);
            ?>

            <a href="<?php echo e(route('student_show_conversation', $conversation->id)); ?>"
               class="list-group-item list-group-item-action py-3 <?php echo e($isUnread ? 'bg-white fw-bold' : 'bg-white'); ?>"
               style="transition: background-color 0.2s ease;">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <h6 class="mb-0 text-dark">
                        <?php echo e($conversation->subject); ?>

                        <?php if($hasAttachments): ?>
                            <span class="ms-1 text-muted">📎</span>
                        <?php endif; ?>
                    </h6>
                    <small class="text-muted">
                        <?php echo e($conversation->updated_at->diffForHumans()); ?>

                    </small>
                </div>

                <div class="d-flex justify-content-between">
                    <p class="mb-0 text-muted">
                        👤 From: <strong><?php echo e($conversation->messages->first()->sender->full_name); ?></strong>
                    </p>
                    <?php if($isUnread): ?>
                        <span class="badge bg-warning align-self-center">New</span>
                    <?php endif; ?>
                </div>

                <p class="mb-0 text-muted mt-1" style="font-size: 0.93rem;">
                    💬 <?php echo e($preview ?: 'No message content.'); ?>

                </p>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
    <div class="text-center text-muted py-5">
        <i class="bi bi-inbox fs-1 d-block mb-2"></i>
        <p class="mb-0">No messages yet. Your inbox is empty.</p>
    </div>
<?php endif; ?>
<?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/partials/messages.blade.php ENDPATH**/ ?>