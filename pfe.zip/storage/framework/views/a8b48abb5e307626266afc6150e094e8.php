<?php if($classes->isEmpty()): ?>
    <p>Sorry, there are no classes for the selected group. Please create a class first: 
        <strong><a href="<?php echo e(route('admin_academic_structure')); ?>">Create Class</a></strong>
    </p>
<?php else: ?>
    <div class="row">
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card classe-card shadow-sm rounded-4 h-100" style="cursor: pointer;" data-id="<?php echo e($class->id); ?>">
                    <div class="card-header bg-primary text-white rounded-top-4 d-flex justify-content-between align-items-center">
                        <h5 class="mb-0 fw-semibold">
                            🧠 <?php echo e($class->module->name); ?> – Group <?php echo e($class->group->name); ?>

                        </h5>
                        <?php if($class->sessionTemplate): ?>
                            <?php if($class->sessionTemplate->status == 'active'): ?>
                                <span 
                                    class="status-dot bg-success rounded-circle" 
                                    data-bs-toggle="tooltip" 
                                    title="🟢 Active – Template is running"
                                ></span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span 
                                class="status-dot bg-danger rounded-circle" 
                                data-bs-toggle="tooltip" 
                                title="🔴 Inactive – Template is Missing or inactive"
                            ></span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <ul class="list-unstyled mb-0">
                            <li><strong>📚 Module:</strong> <?php echo e($class->module->name); ?></li>
                            <li><strong>👥 Group:</strong> <?php echo e($class->group->name); ?></li>
                            <li><strong>🏛️ Section:</strong> <?php echo e($class->group->section->name); ?></li>
                            <li><strong>🎓 Promotion:</strong> <?php echo e($class->group->section->semester->promotion->name); ?></li>
                            <li><strong>🧑‍🏫 Teacher:</strong> <?php echo e($class->teacher->first_name); ?> <?php echo e($class->teacher->last_name); ?></li>
                            <li><strong>🧪 Type:</strong> <?php echo e($class->class_type); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH /home/hexzar/Desktop/pfe/resources/views/admin/partials/result_classe.blade.php ENDPATH**/ ?>