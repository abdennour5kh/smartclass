<?php $__env->startSection('title', 'Tasks'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="card-title">📘 Tasks - <?php echo e($module->name ?? 'N/A'); ?></div>
                <div class="card-description">View and submit your tasks before deadlines.</div>

                <div class="table-responsive mb-5">
                    <table class="table table-bordered table-hover table-striped" id="smartClassTable">
                        <thead class="table-dark">
                            <tr>
                                <th>📌 Title</th>
                                <th>📎 Attachment</th>
                                <th>⏰ Deadline</th>
                                <th>📅 Created</th>
                                <th>📤 Your Submission</th>
                                <th>⚙️ Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $now = now();
                                    $deadline = \Carbon\Carbon::parse($task->deadline);
                                    $submission = $task->submissions->where('student_id', $student->id)->first();
                                ?>
                                <tr>
                                    <td><?php echo e(\Illuminate\Support\Str::limit($task->title, 20)); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $task->teacherFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $fullName = basename($file->file_path);
                                                $extension = pathinfo($fullName, PATHINFO_EXTENSION);
                                                $nameOnly = pathinfo($fullName, PATHINFO_FILENAME);
                                                $limitedName = \Illuminate\Support\Str::limit($nameOnly, 10);
                                            ?>
                                            <a href="<?php echo e(asset('storage/' . $file->file_path)); ?>" target="_blank">📄 <?php echo e($limitedName . '.' . $extension); ?></a><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($deadline->format('d M Y H:i')); ?></td>
                                    <td><?php echo e($task->created_at->format('d M Y')); ?></td>
                                    <td>
                                        <?php if($submission): ?>
                                            <span class="badge bg-success">Submitted</span><br>
                                            <small><?php echo e($submission->created_at->diffForHumans()); ?></small>
                                            <?php if($submission->studentFiles->isNotEmpty()): ?>
                                                <div class="mt-2">
                                                    <?php $__currentLoopData = $submission->studentFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $fullName = basename($file->file_path);
                                                            $extension = pathinfo($fullName, PATHINFO_EXTENSION);
                                                            $nameOnly = pathinfo($fullName, PATHINFO_FILENAME);
                                                            $limitedName = \Illuminate\Support\Str::limit($nameOnly, 10);
                                                        ?>
                                                        <a href="<?php echo e(asset('storage/' . $file->file_path)); ?>" target="_blank">📎 <?php echo e($limitedName . '.' . $extension); ?></a><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Not submitted</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($now->lt($deadline)): ?>
                                            <?php if($submission): ?>
                                                <a href="<?php echo e(route('student_submit_task', $task)); ?>" class="btn btn-sm btn-info">👁️ View</a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('student_submit_task', $task)); ?>" class="btn btn-sm btn-primary">📤 View and Submit</a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">⛔ Deadline Passed</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/tasks.blade.php ENDPATH**/ ?>