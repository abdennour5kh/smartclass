<?php $__env->startSection('title', 'Group Change Request'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-white p-4 border rounded">
    <div class="page-title mb-4">
        🔄 Group Change Request
    </div>

    <?php if(session('success')): ?>
                    <div class="alert alert-success">✅ <?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <h5 class="mb-3">⚠️ Please fix the following issues:</h5>
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
    
    <?php if($requests->count()): ?>
        <div class="mb-5">
            <h5 class="mb-3">📜 Your Previous Requests</h5>
            <div class="list-group">
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong>📅 Submitted:</strong> <?php echo e($req->created_at->format('d M Y H:i')); ?><br>
                                <strong>🎯 Requested Group:</strong> <?php echo e($req->toGroup->name); ?><br>
                                <strong>📝 Reason:</strong> <?php echo e($req->reason); ?>

                            </div>
                            <div>
                                <?php
                                    $status = $req->status;
                                    $label = '⏳ Pending';
                                    $badge = 'warning';

                                    if ($status === 'approved') {
                                        $label = '✅ Approved';
                                        $badge = 'success';
                                    } elseif ($status === 'rejected') {
                                        $label = '❌ Rejected';
                                        $badge = 'danger';
                                    }
                                ?>
                                <span class="badge bg-<?php echo e($badge); ?>"><?php echo e($label); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    
    <h5 class="mb-3 mt-5">🆕 Submit a New Request</h5>
    <form method="POST" action="<?php echo e(route('student_submit_group_change')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group mb-3">
            <label for="target_group_id" class="form-label">👥 Choose Target Group</label>
            <select name="target_group_id" id="target_group_id" class="form-control" required>
                <option disabled selected>-- Select Group --</option>
                <?php $__currentLoopData = $availableGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group mb-4">
            <label for="reason" class="form-label">✍️ Reason for Request</label>
            <textarea name="reason" id="reason" rows="4" class="form-control" required></textarea>
        </div>

        <div class="form-group text-end">
            <button type="submit" class="btn btn-primary">📤 Submit Request</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/change_group.blade.php ENDPATH**/ ?>