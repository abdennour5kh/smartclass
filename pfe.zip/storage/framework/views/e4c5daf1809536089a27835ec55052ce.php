<?php $__env->startSection('title', 'Inbox'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-white" style="padding: 1.5rem 1.875rem !important;border: 1px solid #e7eaed !important;">

<!-- Success Message -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        ✅ <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <!-- Error Message -->
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        ⚠️ Please fix the following issues:
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
    <div class="page-title">
        📥 Inbox
    </div>
    <!-- Tab Navigation -->
    <ul class="nav nav-tabs mb-3 nav-pills" id="structureTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link ac-tab active" data-tabname="messages" id="messages-tab" data-bs-toggle="tab" data-bs-target="#messages" type="button" role="tab">
                ✉️ Messages
            </button>
        </li>
    </ul>

    <!-- Tab Contents -->
    <div class="tab-content bg-white p-4 rounded shadow-sm" id="structureTabsContent">
        <div class="tab-pane fade show active" id="messages" role="tabpanel">
            <?php echo $__env->make('student.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/inbox.blade.php ENDPATH**/ ?>