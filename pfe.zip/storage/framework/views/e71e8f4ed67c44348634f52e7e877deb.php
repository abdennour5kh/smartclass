<?php $__env->startSection('title', 'Announcement'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-white p-4 border rounded">
    <div class="page-title">
        📢 Announcelent - <?php echo e($classe->module->name); ?>

    </div>
    <?php if($announcements->count() > 0): ?>
    <div class="list-group mt-5">
        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="list-group-item">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <strong><?php echo e($announcement->group->name); ?> - <?php echo e($announcement->module->name); ?></strong><br>
                    <small class="text-muted"><?php echo e($announcement->created_at->format('d M Y, H:i')); ?></small>
                    <p class="mb-0 mt-2"><?php echo e($announcement->content); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
    <p class="text-muted">No announcements posted yet.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/announcement.blade.php ENDPATH**/ ?>