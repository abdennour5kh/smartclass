<!-- Group Change Requests List -->
<div class="list-group">
    <?php $__empty_1 = true; $__currentLoopData = $groupChanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="list-group-item">
            <div class="d-flex justify-content-between align-items-start flex-column flex-md-row">
                <div>
                    <div class="mt-2 mt-md-0">
                        <h6 class="text-muted mb-0">
                            <strong><?php echo e($request->student->first_name); ?> <?php echo e($request->student->last_name); ?></strong>
                            requested to change group
                            <strong>from <?php echo e($request->student->group->name); ?></strong>
                            to <strong><?php echo e($request->toGroup->name); ?></strong>
                        </h6>
                    </div>
                </div>
                <div class="mt-2 mt-md-0 text-md-end">
                    <form action="<?php echo e(route('admin_update_group_change')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="change_id" value="<?php echo e($request->id); ?>">
                        <input type="hidden" name="action" value="approve">
                        <button type="submit" class="btn btn-sm btn-success me-2">✅ Approve</button>
                    </form>

                    <form action="<?php echo e(route('admin_update_group_change')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="change_id" value="<?php echo e($request->id); ?>">
                        <input type="hidden" name="action" value="refuse">
                        <button type="submit" class="btn btn-sm btn-danger me-2">❌ Refuse</button>
                    </form>

                    <button class="btn btn-sm btn-inverse-secondary"
                            data-bs-toggle="collapse"
                            data-bs-target="#groupChangeDetails<?php echo e($request->id); ?>"
                            aria-expanded="false"
                            aria-controls="groupChangeDetails<?php echo e($request->id); ?>">
                        ⬇️ Details
                    </button>
                </div>
            </div>

            <!-- Expanded details -->
            <div class="collapse mt-3" id="groupChangeDetails<?php echo e($request->id); ?>">
                <div class="bg-light border rounded p-3">
                    <div class="row mb-2">
                        <div class="col-md-6">
                            <p class="mb-1"><strong>👤 Student:</strong> <?php echo e($request->student->first_name); ?> <?php echo e($request->student->last_name); ?></p>
                            <p class="mb-1"><strong>📛 Registration:</strong> <?php echo e($request->student->registration_num); ?></p>
                            <p class="mb-1"><strong>🎓 Promotion:</strong> <?php echo e($request->student->group->section->semester->promotion->name); ?></p>
                            <p class="mb-1"><strong>📍 Current Group:</strong> <?php echo e($request->student->group->name); ?></p>
                            <p class="mb-1"><strong>📌 Requested Group:</strong> <?php echo e($request->toGroup->name); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-1"><strong>📤 Submitted:</strong> <?php echo e($request->created_at->format('Y-m-d H:i')); ?></p>
                            <p class="mb-1"><strong>📅 Status:</strong>
                                <?php
                                    $statusClass = match($request->status) {
                                        'approved' => 'success',
                                        'refused' => 'danger',
                                        default => 'warning text-dark',
                                    };
                                ?>
                                <span class="badge bg-<?php echo e($statusClass); ?>"><?php echo e(ucfirst($request->status)); ?></span>
                            </p>
                        </div>
                    </div>

                    <div class="mb-3">
                        <strong>📝 Reason:</strong>
                        <div class="border rounded p-2 bg-white mt-1 text-muted">
                            <?php echo e($request->reason ?: 'No reason provided.'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="list-group-item text-center py-5 text-muted">
            <i class="bi bi-inbox fs-4 d-block mb-2"></i>
            No group change requests at the moment.
        </div>
    <?php endif; ?>
</div>

<!-- View History Button -->
<div class="mt-4 text-end">
    <a href="" class="btn btn-outline-secondary">
        📜 View Full Request History
    </a>
</div>
<?php /**PATH /home/hexzar/Desktop/pfe/resources/views/admin/partials/group_changes.blade.php ENDPATH**/ ?>