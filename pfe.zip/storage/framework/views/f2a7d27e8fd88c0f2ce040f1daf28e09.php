<?php $__env->startSection('title', 'Classe Details'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="card-title">
                    📘 Attendance History - <?php echo e($module->name); ?>

                </div>
                <div class="card-description">
                    All your sessions for this module, attendance status, and more.
                </div>
                <!-- Search and Export Row -->
                <div class="d-flex justify-content-between align-items-center my-3 flex-wrap gap-2">
                    <input type="text" id="smartClassTableSearch" class="form-control w-50" placeholder="🔍 Search by teacher, type...">
                </div>

                <!-- Attendance Table -->
                <div class="table-responsive mb-5">
                    <table id="smartClassTable" class="table table-bordered table-hover table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Note</th>
                                <th>Status</th>
                                <th>Teacher</th>
                                <th>Room</th>
                                <th>Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($entry['date']); ?></td>
                                <td><?php echo e($entry['start']); ?> - <?php echo e($entry['end']); ?></td>
                                <td><?php echo e($entry['note']); ?></td>
                                <?php if($entry['status'] == 'present'): ?>
                                <td><span class="badge bg-success">Present</span></td>
                                <?php endif; ?>
                                <?php if($entry['status'] == 'absent'): ?>
                                <td><span class="badge bg-warning">Absent</span></td>
                                <?php endif; ?>
                                <?php if($entry['status'] == 'late'): ?>
                                <td><span class="badge bg-warning">Late</span></td>
                                <?php endif; ?>
                                <?php if($entry['status'] == 'justified'): ?>
                                <td><span class="badge bg-warning">Justified</span></td>
                                <?php endif; ?>
                                <?php if($entry['status'] == 'excused'): ?>
                                <td><span class="badge bg-success">Excused</span></td>
                                <?php endif; ?>
                                <td><?php echo e($entry['teacher']); ?></td>
                                <td><?php echo e($entry['room']); ?></td>
                                <td><?php echo e($entry['type']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/pfe/resources/views/student/class_details.blade.php ENDPATH**/ ?>